#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
struct node
{
    node *l,*r;
    ll b,d,h,s;
    node(ll p)
    {
        d=p;
        h=0;
        b=0;
        s=1;
        l=NULL;
        r=NULL;
    }
};
class Avl
{
public:
    node *root;
    Avl()
    {
      root=NULL;
    }
    ll kth(node *root, ll p)
    {
    ll lc =!root->l?0:root->l->s;
    if(p<lc+1)
        return kth(root->l, p);
    if(p==lc+1)
        return root->d;
    return kth(root->r,p-lc-1);
    }
    ll kth(ll p)
    {
    return kth(root,p);
    }
    node* RL(node *root)
   {
    node *temp=root->r;
    root->r=temp->l;
    temp->l=root;
    root->b=(root->b)-1-max(temp->b,(ll)0);
    temp->b=(temp->b)-1+min(root->b,(ll)0);
    ll hl=!root->l?0:root->l->h;
    ll sl=!root->l?0:root->l->s;
    ll hr=!root->r?0:root->r->h;
    ll sr=!root->r?0:root->r->s;
    root->h=max(hr,hl)+1;
    root->s=sl+sr+1;
     hl=!temp->l?0:temp->l->h;
     sl=!temp->l?0:temp->l->s;
     hr=!temp->r?0:temp->r->h;
     sr=!temp->r?0:temp->r->s;
    temp->h=max(hr,hl)+1;
    temp->s=sl+sr+1;
    return temp;
   }
   node* RR(node *root)
   {
    node *temp=root->l;
    root->l=temp->r;
    temp->r=root;
    root->b=(root->b)+1-min(temp->b,(ll)0);
    temp->b=(temp->b)+1+max(root->b,(ll)0);
    ll hl=!root->l?0:root->l->h;
    ll sl=!root->l?0:root->l->s;
    ll hr=!root->r?0:root->r->h;
    ll sr=!root->r?0:root->r->s;
    root->h=max(hr,hl)+1;
    root->s=sl+sr+1;
     hl=!temp->l?0:temp->l->h;
     sl=!temp->l?0:temp->l->s;
     hr=!temp->r?0:temp->r->h;
     sr=!temp->r?0:temp->r->s;
    temp->h=max(hr,hl)+1;
    temp->s=sl+sr+1;
    return temp;
   }
   node* RRL(node *root)
   {
    root->l = RL(root->l);
    ll hl=!root->l?0:root->l->h;
    ll sl=!root->l?0:root->l->s;
    ll hr=!root->r?0:root->r->h;
    ll sr=!root->r?0:root->r->s;
    root->h=max(hr,hl)+1;
    root->s=sl+sr+1;
    root->b=hr-hl;
    return RR(root);
   }
   node* RLR(node *root)
   {
    root->r = RR(root->r);
    ll hl=!root->l?0:root->l->h;
    ll sl=!root->l?0:root->l->s;
    ll hr=!root->r?0:root->r->h;
    ll sr=!root->r?0:root->r->s;
    root->h=max(hr,hl)+1;
    root->s=sl+sr+1;
    root->b=hr-hl;
    return RL(root);
   }
   node* insert(node *root,ll p)
   {
    if(p<root->d)
    {
        if(!root->l)
            root->l=new node(p);
        else
        root->l= insert(root->l,p);
    }
    if(p>=root->d)
    {
        if(!root->r)
            root->r=new node(p);
        else
        root->r=insert(root->r,p);
    }
    ll hl=!root->l?0:root->l->h;
    ll sl=!root->l?0:root->l->s;
    ll hr=!root->r?0:root->r->h;
    ll sr=!root->r?0:root->r->s;
    root->h=max(hr,hl)+1;
    root->s=sl+sr+1;
    root->b=hr-hl;
    if(root->b<-1)
    {
        if(root->l->b>0)
            return RRL(root);
        else
            return RR(root);
    }
    if(root->b>1)
    {
        if(root->r->b<0)
            return RLR(root);
        else
        return RL(root);
    }
    return root;
    }
    ll ins(node *root)
    {
      if(root->l==NULL)
        return root->d;
 
     return ins(root->l);
    }
    void insert(ll p)
    {
    if(!root)
    {
        root=new node(p);
        return;
    }
    root=insert(root,p);
    }
    void vo(node * root)
    {
      if(root)
      {
        cout<<root->d;
        vo(root->l);
        vo(root->r);
      }
    }
    ll size()
    {
        return root->s;
    }
    ll heigh()
    {
        return root->h;
    }
    ll data()
    {
        return root->d;
    }
    ll balancefactor()
    {
        return root->b;
    }
    node* left()
    {
        return root->l;
    }
    node* right()
    {
        return root->r;
    }
    void vo()
    {
      return vo(root);
    }
    double med(node * root)
    {
        if(root->s%2==0)
        {
            double ans =kth((root->s)/2);
            ans+=(kth(((root->s)/2)+1));
            ans=ans/2.0;
            return ans;
        }
        else 
        {
            return kth(((root->s)/2+1))/1.0;
        }
    }
    double median()
    {
        return med(root);
    }
    void in(node *root)
    {
        if(root)
        {
            in(root->l);
            cout<<root->d;
            in(root->r);
        }
    }
    void in()
    {
        in(root);
    }
    bool search(node * root,ll key)
    {
        if(key<root->d)
        {
            if(!root->l) return false;
            else if(key==root->d) 
              return true;
            else
               {
                   return search(root->l,key);
               }
        }
        if(key>root->d)
       {
           if(!root->r) return false;
           else if(root->d==key)
             return true;
        else
         {
             return search(root->r,key);
         }
     }
   }
    bool serach(ll key)
    {
        return search(root,key);
    }
     void closestG(node * root,ll k,ll &mini,ll &miniV,ll &maxi, ll &temp)
    {
       // cout<<"\nfor root "<<root->d<<" "<<k<<endl;
        if(root->d==k)
          {
              miniV=root->d;
              temp=root->d;
              return;
           } 
        
         if(root->d>=k)
         {
            // cout<<"root data is > k"<<endl;
             if(maxi>abs(root->d-k))
             {
                 //cout<<"maxi updated"<<endl;
                 maxi=abs(root->d-k);
                 temp=root->d;
             }
         }
         if(root->d<=k){
            // cout<<"root data is < k"<<endl;
       if(mini>abs(root->d-k))
       {
           //cout<<"mini updated"<<endl;
          mini=abs(root->d-k);
          miniV=root->d;
          
          
      }
         }
         
         if(k<root->d)
        {
            if(root->l){
            
           // cout<<"go left\n";
            return closestG(root->l,k,mini,miniV,maxi,temp);
          }
        }
         else
         {
             if(root->r){
             
            // cout<<"go right\n";
             return closestG(root->r,k,mini,miniV,maxi,temp);
            }
         }
           
    }
    
    ll closestGm(ll k)
    {
        ll mini=1e6,maxi=1e6,miniV=-1e6,temp=-1e6;
        closestG(root,k,mini,miniV,maxi,temp);
        return miniV;
    }
    ll closestGM(ll k)
    {
        ll mini=1e6,maxi=1e6,miniV=-1e6,temp=-1e6;
        closestG(root,k,mini,miniV,maxi,temp);
        return temp;
    }
     void closest(node * root,ll k,ll &mini,ll &miniV)
    {
        if(root->d==k)
          {    miniV=root->d;
              return;
           } 
         if(mini==abs(root->d-k))
         {    miniV=miniV<root->d?miniV:root->d;
         }
         if(mini>abs(root->d-k))
         {
             
             mini=abs(root->d-k);
             miniV=root->d;
             
         }
         
         if(k<root->d)
        {
            if(root->l){
            
            return closest(root->l,k,mini,miniV);
          }
        }
         else
         {
             if(root->r){
             return closest(root->r,k,mini,miniV);
            }
         }
           
    }
};
int main()
{
   Avl mmmmm;
   ll i,j;
   cin>>i;
   while(i--)
   {
       cin>>j;
       mmmmm.insert(j);
       cout<<mmmmm.median()<<endl;

   }
}
