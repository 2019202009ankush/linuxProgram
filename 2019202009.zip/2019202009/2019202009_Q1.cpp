#include<bits/stdc++.h>
using namespace std;
struct node
{
	vector<int>d;
	vector<node *>ptr;
	int count;
	int order;
	bool isleaf;
	node(int n,int v)
	{
		vector<int>d(n);
		vector<node *>ptr(n,NULL);
		count=1;
		order=n;
		isleaf=1;
		d.push_back(v);
	}
};
class btree{
	public:
	node * root;
	int o;
	btree(int x)
	{
	  o=x;	root=NULL;
	}
	
	void insert(int p)
	{
		if(root==NULL)
		{
			root=new node(o,p);
			return;
		}
		else
		{
		if(root->count==o)
		{
			root->isleaf=false;
			root->d.push_back(p);
			sort(root->d.begin(),root->d.end());
			int temp=root->d[o/2];
			node*s=new node(o,temp);
			int i;
			for( i=0;i<o;i++)
			{
				if(i<o/2)
				{
				 
				s->ptr[0]->d[i]=root->d[i];
				s->ptr[0]->count++;
			    }
				else
				s->ptr[0]->d[i]=-1;
				
			}
			
			for(int k=o/2;k<o;k++,i++)
			{
				if(i>=o/2){
				
				s->ptr[1]->d[k-(o/2)]=root->d[i];
				s->ptr[1]->count++;
			  }
				else
				s->ptr[0]->d[k-(o/2)]=-1;
			}
			root=s;
			
		}
		else
		{
			if(root->isleaf==true){
			
			root->d.push_back(p);
			sort(root->d.begin(),root->d.end());
			root->count++;
		  }
		else{
			int i=o-1;
			while(i>=0&&root->d[i]>p)
			i--;
			if(root->ptr[i+1]->count==o)
			{
			root->ptr[i+1]->isleaf=false;
			root->ptr[i+1]->d.push_back(p);
			sort(root->ptr[i+1]->d.begin(),root->ptr[i+1]->d.end());
			int temp=root->ptr[i+1]->d[o/2];
			node*s=new node(o,temp);
			int i;
			for( i=0;i<o;i++)
			{
				if(i<o/2)
				{
				 
				s->ptr[0]->d[i]=root->ptr[i+1]->d[i];
				s->ptr[0]->count++;
			    }
				else
				s->ptr[0]->d[i]=-1;
				
			}
			
			for(int k=o/2;k<o;k++,i++)
			{
				if(i>=o/2){
				
				s->ptr[1]->d[k-(o/2)]=root->ptr[i+1]->d[i];
				s->ptr[1]->count++;
			  }
				else
				s->ptr[0]->d[k-(o/2)]=-1;
			}
			root->ptr[i+1]=s;
			}
		}
      }
		}
	}
	void traverse(node * root)
	{
		if(root->isleaf!=1)
		{
			for(int i=0;i<o;i++)
			{
				traverse(root->ptr[i]);
			}
		}
		else
		{
			for(int i=0;i<o;i++)
			{
				cout<<(root->d[i])<<endl;
			}
		}
	}
	void traverse()
	{
		traverse(root);
	}
	
};
int main()
{
	btree b(5);
	b.insert(1);
	b.insert(2);
	b.insert(3);
	b.traverse();
	
}

