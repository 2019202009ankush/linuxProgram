#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
template<typename T>
struct node
{
    node *l,*r;
    ll b,h,s;
    T d;
    node(T p)
    {
        d=p;
        h=0;
        b=0;
        s=1;
        l=NULL;
        r=NULL;
    }
};
int count=0;
template<class T>
class Avl
{
public:
    node<T> *root;
    Avl()
    {
      root=NULL;
    }
    ll kth(node<T> *root, ll p)
    {
    ll lc =!root->l?0:root->l->s;
    if(p<lc+1)
        return kth(root->l, p);
    if(p==lc+1)
        return root->d;
    return kth(root->r,p-lc-1);
    }
    ll kth(ll p)
    {
    return kth(root,p);
    }
    node<T>* RL(node<T> *root)
   {
    node<T> *temp=root->r;
    root->r=temp->l;
    temp->l=root;
    root->b=(root->b)-1-max(temp->b,(ll)0);
    temp->b=(temp->b)-1+min(root->b,(ll)0);
    ll hl=!root->l?0:root->l->h;
    ll sl=!root->l?0:root->l->s;
    ll hr=!root->r?0:root->r->h;
    ll sr=!root->r?0:root->r->s;
    root->h=max(hr,hl)+1;
    root->s=sl+sr+1;
     hl=!temp->l?0:temp->l->h;
     sl=!temp->l?0:temp->l->s;
     hr=!temp->r?0:temp->r->h;
     sr=!temp->r?0:temp->r->s;
    temp->h=max(hr,hl)+1;
    temp->s=sl+sr+1;
    return temp;
   }
   node<T>* RR(node<T> *root)
   {
    node<T> *temp=root->l;
    root->l=temp->r;
    temp->r=root;
    root->b=(root->b)+1-min(temp->b,(ll)0);
    temp->b=(temp->b)+1+max(root->b,(ll)0);
    ll hl=!root->l?0:root->l->h;
    ll sl=!root->l?0:root->l->s;
    ll hr=!root->r?0:root->r->h;
    ll sr=!root->r?0:root->r->s;
    root->h=max(hr,hl)+1;
    root->s=sl+sr+1;
     hl=!temp->l?0:temp->l->h;
     sl=!temp->l?0:temp->l->s;
     hr=!temp->r?0:temp->r->h;
     sr=!temp->r?0:temp->r->s;
    temp->h=max(hr,hl)+1;
    temp->s=sl+sr+1;
    return temp;
   }
   node<T>* RRL(node<T> *root)
   {
    root->l = RL(root->l);
    ll hl=!root->l?0:root->l->h;
    ll sl=!root->l?0:root->l->s;
    ll hr=!root->r?0:root->r->h;
    ll sr=!root->r?0:root->r->s;
    root->h=max(hr,hl)+1;
    root->s=sl+sr+1;
    root->b=hr-hl;
    return RR(root);
   }
   node<T>* RLR(node<T> *root)
   {
    root->r = RR(root->r);
    ll hl=!root->l?0:root->l->h;
    ll sl=!root->l?0:root->l->s;
    ll hr=!root->r?0:root->r->h;
    ll sr=!root->r?0:root->r->s;
    root->h=max(hr,hl)+1;
    root->s=sl+sr+1;
    root->b=hr-hl;
    return RL(root);
   }
   node<T>* insert(node<T> *root,ll p)
   {
    if(p<root->d)
    {
        if(!root->l)
            root->l=new node<T>(p);
        else
        root->l= insert(root->l,p);
    }
    if(p>root->d)
    {
        if(!root->r)
            root->r=new node<T>(p);
        else
        root->r=insert(root->r,p);
    }
    ll hl=!root->l?0:root->l->h;
    ll sl=!root->l?0:root->l->s;
    ll hr=!root->r?0:root->r->h;
    ll sr=!root->r?0:root->r->s;
    root->h=max(hr,hl)+1;
    root->s=sl+sr+1;
    root->b=hr-hl;
    if(root->b<-1)
    {
        if(root->l->b>0)
            return RRL(root);
        else
            return RR(root);
    }
    if(root->b>1)
    {
        if(root->r->b<0)
            return RLR(root);
        else
        return RL(root);
    }
    return root;
    }
    void insert(ll p)
    {
    if(!root)
    {
        root=new node<T>(p);
        return;
    }
    root=insert(root,p);
    }
    void vo(node<T> * root)
    {
      if(root)
      {
        cout<<root->d;
        vo(root->l);
        vo(root->r);
      }
    }
    ll size()
    {
        return root->s;
    }
    ll heigh()
    {
        return root->h;
    }
    ll data()
    {
        return root->d;
    }
    ll balancefactor()
    {
        return root->b;
    }
    node<T>* left()
    {
        return root->l;
    }
    node<T>* right()
    {
        return root->r;
    }
    void vo()
    {
      return vo(root);
    }
    double med(node<T> * root)
    {
        if(root->s%2==0)
        {
            double ans =kth((root->s)/2);
            ans+=(kth(((root->s)/2)+1));
            ans=ans/2.0;
            return ans;
        }
        else 
        {
            return kth(((root->s)/2+1))/1.0;
        }
    }
    double median()
    {
        return med(root);
    }
    ll ins(node<T>* root)
    {
        while(root->l)
         root=root->l;
         return root->d;
    }
node<T>* delet(node<T> *root, ll p)
{
    if(p<root->d)
    {
        if(!root->l)
            return root;
        else
        root->l=delet(root->l, p);
    }
    if(p>root->d)
    {
        if(!root->r)
            return root;
       else
         root->r=delet(root->r, p);
    }
    if(p==root->d)
    {
        ll count=0;
        count+=!root->l?0:1;
        count+=!root->r?0:1;
        if(count == 0)
            return NULL;
        if(count==1)
            return !root->l?root->r:root->l;
        if(count==2)
        {
            ll k=ins(root->r);
            root->r=delet(root->r, k);
            root->d=k;
        }
    }
            ll hl=!root->l?0:root->l->h;
    ll sl=!root->l?0:root->l->s;
    ll hr=!root->r?0:root->r->h;
    ll sr=!root->r?0:root->r->s;
    root->h=max(hr,hl)+1;
    root->s=sl+sr+1;
    root->b=hr-hl;
    if(root->b<-1)
    {
        if(root->l->b>0)
            return RRL(root);
        else
            return RR(root);
    }
    if(root->b>1)
    {
        if(root->r->b<0)
            return RLR(root);
        else
        return RL(root);
    }
    return root;
    }
    void delet(ll p)
    {
        if(root==NULL)
        {
            cout<<"deletion in empty set is not possible";
            return;
            
        }
        else
         root=delet(root,p);
    }
    void dis(node<T> * root)
    {
        if(root)
        {
            dis(root->l);
            cout<<root->d;
            dis(root->r);
        }
        
    }
    void dis()
    {
        cout<<"Displaying ordered set";
        dis(root);
        cout<<endl;
    }
    bool search(node<T> * root,T key)
    {
        if(key<root->d)
        {
            if(!root->l) return false;
            else if(key==root->d) 
              return true;
            else
               {
                   return search(root->l,key);
               }
        }
        if(key>root->d)
       {
           if(!root->r) return false;
           else if(root->d==key)
             return true;
        else
         {
             return search(root->r,key);
         }
     }
 }
    bool serach(T key)
    {
        return search(root,key);
    }
    
    
    void closest(node<T> * root,T k,T &mini,T &miniV)
    {
        if(root->d==k)
          {    miniV=root->d;
              return;
           } 
         if(mini==abs(root->d-k))
         {    miniV=miniV<root->d?miniV:root->d;
         }
         if(mini>abs(root->d-k))
         {
             
             mini=abs(root->d-k);
             miniV=root->d;
             
         }
         
         if(k<root->d)
        {
            if(root->l){
            
            return closest(root->l,k,mini,miniV);
          }
        }
         else
         {
             if(root->r){
             return closest(root->r,k,mini,miniV);
            }
         }
           
    }
    void closestG(node<T> * root,T k,T &mini,T &miniV,T &maxi, T &temp)
    {
       // cout<<"\nfor root "<<root->d<<" "<<k<<endl;
        if(root->d==k)
          {
              miniV=root->d;
              temp=root->d;
              return;
           } 
        
         if(root->d>=k)
         {
            // cout<<"root data is > k"<<endl;
             if(maxi>abs(root->d-k))
             {
                 //cout<<"maxi updated"<<endl;
                 maxi=abs(root->d-k);
                 temp=root->d;
             }
         }
         if(root->d<=k){
            // cout<<"root data is < k"<<endl;
       if(mini>abs(root->d-k))
       {
           //cout<<"mini updated"<<endl;
          mini=abs(root->d-k);
          miniV=root->d;
          
          
      }
         }
         
         if(k<root->d)
        {
            if(root->l){
            
           // cout<<"go left\n";
            return closestG(root->l,k,mini,miniV,maxi,temp);
          }
        }
         else
         {
             if(root->r){
             
            // cout<<"go right\n";
             return closestG(root->r,k,mini,miniV,maxi,temp);
            }
         }
           
    }
    T closest(T k)
    {
        T mini=1e6,miniV=-1e6;
        closest(root,k,mini,miniV);
        return miniV;
    }
    T closestGm(T k)
    {
        T mini=1e6,maxi=1e6,miniV=-1e6,temp=-1e6;
        closestG(root,k,mini,miniV,maxi,temp);
        return miniV;
    }
    T closestGM(T k)
    {
        T mini=1e6,maxi=1e6,miniV=-1e6,temp=-1e6;
        closestG(root,k,mini,miniV,maxi,temp);
        return temp;
    }
    void age(node<T>* root,T k,ll &temp)
    {
        //cout<<"checki for root"<<root->d<<endl;
      if(root->d==k)
       {
            return;
       }
        if(k<root->d)
        {
            ll right=!root->l->r?0:root->l->r->s;
            temp=temp-1-right;
            //cout<<"temp updated going left side"<<temp<<endl;
            return age  (root->l,k,temp);
        }
        if(k>root->d)
        {
            ll left=!root->r->l?0:root->r->l->s;
            //cout<<left<<endl;
            temp=temp+1+left;
            //cout<<"temp updated going right side"<<temp<<endl;
            return age  (root->r,k,temp);
        }
    }
    ll age(T k)
    {
        //cout<<root->s<<endl;
        ll temp=root->l->s;
        // cout<<temp<<endl;
         age(root,k,temp);
         return temp;
    }
    ll range(ll u,ll r )
    {
        T ug=closestGM(u);
        T rl=closestGm(r);
       // cout<<ug<<" "<<rl<<endl;
        ll agei=age(ug);
        //cout<<agei;
        //cout<<"-------------------------------------"<<endl;
        ll ager=age(rl);
        //cout<<ager<<"-------------------------------------"<<endl;
        return ager-agei+1;
    }
    
};
int main()
{
   Avl<int>mmmmm;
   mmmmm.insert(1);
   mmmmm.insert(2);
   mmmmm.dis();
   mmmmm.delet(1);
   mmmmm.dis();
   mmmmm.delet(2);
  // mmmmm.insert(8);
   cout<<"hi";
   mmmmm.dis();
   mmmmm.insert(20);
   mmmmm.insert(3);
   mmmmm.insert(25);
   mmmmm.insert(2);
   mmmmm.insert(9);
   mmmmm.insert(6);
   mmmmm.insert(7);
   mmmmm.insert(10);
   mmmmm.insert(23);
   mmmmm.insert(27);
   mmmmm.insert(28);
   mmmmm.insert(26);
   mmmmm.dis();
   mmmmm.vo();
   cout<<mmmmm.closestGm(5);
   cout<<mmmmm.closestGm(3);
   cout<<mmmmm.closestGm(14);
   cout<<mmmmm.closestGm(22);
   
   cout<<endl;
   cout<<mmmmm.closestGM(5);
   cout<<mmmmm.closestGM(3);
   cout<<mmmmm.closestGM(14);
   cout<<mmmmm.closestGM(22);
   cout<<endl;
   cout<<mmmmm.closest(2);
   cout<<mmmmm.closest(3);
   cout<<mmmmm.closest(4);
   
   //cout<<mmmmm.closest(2);
   cout<<mmmmm.closest(6);
   cout<<endl;
     mmmmm.insert(10);
    cout<<mmmmm.closest(9);
     mmmmm.dis();
     cout<<endl;
    /*cout<<mmmmm.age(6)<<endl;
    cout<<mmmmm.age(20)<<endl;
    cout<<mmmmm.age(26)<<endl;
    cout<<mmmmm.age(28)<<endl;
    cout<<mmmmm.age(23)<<endl;*/
    //cout<<"_______________________________"<<endl;
    cout<<mmmmm.range(5,24);
   
   
   
}
